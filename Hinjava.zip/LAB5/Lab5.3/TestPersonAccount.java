import java.util.Random;


public class TestPersonAccount 
{
	public static void main(String args[])
	{
		Random rand=new Random();
		Account smith=new Savings();
		Person pSmith=new Person();
		pSmith.setName("Smith");
		pSmith.setAge(20);
		smith.setAccHolder(pSmith);
		smith.setAccountBal(2000);
		smith.setAccountNum(Math.abs(rand.nextLong()));
		
		
		Account kathy=new Savings();
		Person pKathy=new Person();
		pKathy.setName("Smith");
		pKathy.setAge(24);
		kathy.setAccHolder(pKathy);
		kathy.setAccountBal(3000);
		kathy.setAccountNum(Math.abs(rand.nextLong()));
		
		smith.deposite(2000);
		System.out.println("smith balance:"+smith.getBalance());
		kathy.withdraw(2000);
		System.out.println("kathy balance:"+kathy.getBalance());
		Savings svAccount=new Savings();
		svAccount.setAccountBal(5000);
		svAccount.withdraw(500);
		
		Current curAccount=new Current();
		curAccount.setOverDftLim(5000);
		curAccount.setAccountBal(5000);
		curAccount.withdraw(500);
	}
}
