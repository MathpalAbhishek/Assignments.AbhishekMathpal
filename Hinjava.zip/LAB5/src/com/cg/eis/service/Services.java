package com.cg.eis.service;
import java.util.Scanner;

import com.cg.eis.bean.Employee;


public class Services extends Employee implements EmpService
{
	Employee emp=new Employee();
	Scanner sc=new Scanner(System.in);
	public void showDetails()
	{
		System.out.println("ID="+emp.getId());
		System.out.println("Name="+emp.getName());
		System.out.println("Salary="+emp.getSalary());
		System.out.println("Designation="+emp.getDesgnl());
		System.out.println("Scheme="+emp.getInsrSchm());
	}
	
	public void putDetails()
	{
		System.out.println("Enter id,name,salary,designation");
		emp.setId(sc.nextInt());
		emp.setName(sc.next());
		emp.setSalary(sc.nextDouble());
		emp.setDesgnl(sc.next());
		emp.setInsrSchm(getInsSchm(emp.getSalary(),emp.getDesgnl()));
	}
	public String getInsSchm(double sal,String desgn)
	{
		String insSch=null;
		if(sal<5000 && desgn.equals("Clerk"))
		{
			insSch="No scheme";
		}
		else if(((sal>=5000)&&(sal<20000))&&(desgn.equals("System associate")))
		{
			insSch="scheme C";
		}
		else if(((sal>=20000)&&(sal<40000))&&(desgn.equals("Programmer")))
		{
			insSch="scheme B";
		}
		else if(((sal>=40000)&&(sal<80000))&&(desgn.equals("Manager")))
		{
			insSch="scheme A";
		}
		return insSch;
	}
}
