
public interface MobileFeatures {
	public String flash();
	public String camera();
}
