
public class Mobile1 implements MobileFeatures
{
	@Override
	public String camera() {
		return "12 MegaPixel";
	}

	@Override
	public String flash() {
		return "Xenon Flash";
	}
}
