
public class Savings extends Account
{
	final double minBal=500;
	public double getMinBalance()
	{
		return minBal;
	}
	public void withdraw(double amount)
	{
		if(amount>accountBal)
		{
			System.out.println("not sufficient funds");
		}
			else if(accountBal-amount<minBal)
			{
				System.out.println("Low Balance");
			}
			else
			{
				accountBal=accountBal-amount;
				System.out.println("Txn Successfull,Balance:"+accountBal);
			}
		}
}