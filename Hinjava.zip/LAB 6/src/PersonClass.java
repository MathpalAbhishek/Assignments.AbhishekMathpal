import java.util.*;
class PersonDi {
	String name;
	String Lname;
	char gen;
	PersonDi()
	{
		name="";
		Lname="";
	}
	public void setter(String n,String l,char gen)
	{
		name=n;
		Lname=l;
		this.gen=gen;
	}
	public void getter()
	{
		System.out.println(name);
		System.out.println(Lname);
		System.out.println(gen);
	}
}
public class PersonClass {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		PersonDi obj=new PersonDi();
		System.out.println("Enter First name and Last name");
		String fName=sc.next();
		String lName=sc.next();
		char c=sc.next().charAt(0);
		if(fName.equals(".")&&lName.equals("."))
		{
			throw new BlankUserNameException("Blank user name Exception");
		}
		else{
		obj.setter(fName, lName, c);
		obj.getter();
		}
	}
}
