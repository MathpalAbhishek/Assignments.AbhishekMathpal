package com.cg.eis.exception;

public class LowSalaryException extends RuntimeException
{

	public LowSalaryException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LowSalaryException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public LowSalaryException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public LowSalaryException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public LowSalaryException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}



}
