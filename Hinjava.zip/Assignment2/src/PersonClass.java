class PersonDi {
	String name;
	String Lname;
	char gen;
	
	public PersonDi(String name, String lname, char gen) {
		super();
		this.name = name;
		Lname = lname;
		this.gen = gen;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLname() {
		return Lname;
	}

	public void setLname(String lname) {
		Lname = lname;
	}

	public char getGen() {
		return gen;
	}

	public void setGen(char gen) {
		this.gen = gen;
	}
	
}
public class PersonClass {
	public static void main(String args[])
	{
		PersonDi obj=new PersonDi("saloni", "gupta", 'M');
		//getting name
		System.out.println(obj.getName());
		//setting new name
		obj.setName("abhi");
		//getting new name
		System.out.println(obj.getName());
	}
}
