class PersonDii {
	String name;
	String Lname;
	char gen;
	long ph;
	static int count;
	public PersonDii()
	{
		name="";
		Lname="";
		ph=0;
	}
	public PersonDii(String name,String Lname,char gen,long ph)
	{
		this.name=name;
		this.Lname=Lname;
		this.gen=gen;
		this.ph=ph;
		count++;
	}
	public void getter()
	{
		System.out.println(name);
		System.out.println(Lname);
		System.out.println(gen);
		System.out.println(ph);
	}
	public static int count()
	{
		return count;
	}
}



public class PersonDetailPhone {
	public static void main(String args[])
	{
		PersonDii obj=new PersonDii();
		obj=new PersonDii("Divya","Bharti",'F',859111);
		//obj.setter("Divya","Bharti",'F',859111);
		obj.getter();
		PersonDii obj2=new PersonDii();
		obj2=new PersonDii("ivya","Bhart",'M',849111);
		//obj.setter("Divya","Bharti",'F',859111);
		obj2.getter();
		System.out.println(PersonDii.count());
	}

}
