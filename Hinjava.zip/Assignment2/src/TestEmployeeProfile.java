import java.util.Scanner;
public class TestEmployeeProfile {
	public static void main(String args[])
	{
		Employee obj=new Employee();
		Scanner sc=new Scanner(System.in);


		int eID,sal;
		int genchoose;
		String name=new String();
		GenderEmployee gender=null;


		System.out.println("Enter name of employee");
		name=sc.next();
		System.out.println("Enter EID of employee");
		eID=sc.nextInt();
		System.out.println("Enter Salary of employee");
		sal=sc.nextInt();
		System.out.println("Enter 1 for male and 2 for female");
		genchoose=sc.nextInt();


		switch(genchoose)
		{
			case 1:gender=GenderEmployee.MALE;break;
			case 2:gender=GenderEmployee.FEMALE;break;
			default: gender=GenderEmployee.Wrong_Input;
		}

		obj.setName(name);
		obj.setEid(eID);
		obj.setSalary(sal);
		obj.setGender(gender);
		System.out.println("DATA");
		System.out.println("EID="+obj.getEid());
		System.out.println("NAME="+obj.getName());
		System.out.println("SALARY="+obj.getSalary());
		System.out.println("GENDER="+obj.getGender());
	}
}
