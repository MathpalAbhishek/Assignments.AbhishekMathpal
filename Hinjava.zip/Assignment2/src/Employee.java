
public class Employee {
	public Employee(){}
	private int eId;
	private String name;
	private int salary;
	private GenderEmployee gend=null;
	//getter
	public int getEid()
	{
		return eId;
	}
	public int getName()
	{
		return eId;
	}
	public int getSalary()
	{
		return eId;
	}
	public GenderEmployee getGender()
	{
		return gend;
	}
	//setter
	public void setEid(int eId)
	{
		this.eId=eId;
	}
	public void setName(String name)
	{
		this.name=name;
	}
	public void setSalary(int salary)
	{
		this.salary=salary;
	}
	public void setGender(GenderEmployee gen)
	{
		gend=gen;
	}
}
