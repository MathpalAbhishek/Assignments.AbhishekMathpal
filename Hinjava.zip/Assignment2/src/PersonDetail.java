class PersonD
{
	String name;
	String Lname;
	char gen;
	int age;
	double weight;
	public void setData(String n,String l,char gen,int age,double weight)
	{
		name=n;
		Lname=l;
		this.gen=gen;
		this.age=age;
		this.weight=weight;
	}
	public void display()
	{
		System.out.println(name);
		System.out.println(Lname);
		System.out.println(gen);
		System.out.println(age);
		System.out.println(weight);
	}
}
public class PersonDetail {
	public static void main(String args[])
	{
		PersonD div=new PersonD();
		div.setData("Divya","Bharti",'F',20,85.55);
		div.display();
	}
}
